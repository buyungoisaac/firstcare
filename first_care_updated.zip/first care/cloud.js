/* Firebase layer: shared sign-in (name + 4-digit PIN), worker list and facility settings.
   The Firebase web config is public by design. What protects the data is firestore.rules. */
const FB_CONFIG={
  apiKey:"AIzaSyCujdSL6uxI7mDKi5EYDwHkIATcwCsusC0",
  authDomain:"firstcarepos.firebaseapp.com",
  projectId:"firstcarepos",
  storageBucket:"firstcarepos.firebasestorage.app",
  messagingSenderId:"426999112198",
  appId:"1:426999112198:web:3904eed4d6d9f101429987"
};
const cloud=(function(){
  if(typeof firebase==="undefined")return null; /* SDK could not be loaded (offline) */
  const app=firebase.initializeApp(FB_CONFIG),auth=app.auth(),db=app.firestore();
  /* nobody stays signed in after the page closes (shared pharmacy devices) */
  const noPersist=auth.setPersistence(firebase.auth.Auth.Persistence.NONE).catch(()=>{});
  const ALL=["dash","inv","pos","rcpt","rx","team","facility"];
  /* Firebase Auth needs 6+ characters, so a fixed suffix is added to the 4-digit PIN */
  const pw=pin=>pin+"-fc";
  const emailOf=name=>{
    let s=name.trim().toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g,"").replace(/[^a-z0-9]+/g,".").replace(/^\.+|\.+$/g,"");
    if(!s)s="w"+[...name.trim()].map(c=>c.charCodeAt(0).toString(16)).join("");
    return s+"@firstcare.app";
  };
  const ts=()=>firebase.firestore.FieldValue.serverTimestamp();
  const wfrom=d=>({id:d.id,...d.data()});
  const err=(code,msg)=>Object.assign(new Error(msg),{code});
  const net=e=>e&&(e.code==="auth/network-request-failed"||e.code==="unavailable"||e.code==="failed-precondition");

  return {
    /* has the first (owner) account been created yet? */
    async isSetup(){
      try{const s=await db.doc("meta/setup").get();return s.exists;}
      catch(e){throw err("network","Cannot reach the server. Check the internet connection.");}
    },
    /* the first account on a fresh system becomes the owner and administrator */
    async registerOwner(name,pin){
      await noPersist;
      const email=emailOf(name);let cred;
      try{cred=await auth.createUserWithEmailAndPassword(email,pw(pin));}
      catch(e){
        if(net(e))throw err("network","Cannot reach the server. Check the internet connection.");
        if(e.code==="auth/email-already-in-use"){
          try{cred=await auth.signInWithEmailAndPassword(email,pw(pin));}
          catch(_){throw err("taken","This system already has an account with that name.");}
        }else throw err(e.code,"Could not create the account. "+(e.message||""));
      }
      const uid=cred.user.uid,b=db.batch();
      b.set(db.doc("workers/"+uid),{name,nameLower:name.toLowerCase(),role:"Admin",slot:1,owner:true,access:ALL,created:ts()});
      b.set(db.doc("meta/setup"),{initialized:true,owner:uid,created:ts()});
      try{await b.commit();}
      catch(e){
        try{await cred.user.delete();}catch(_){}
        try{await auth.signOut();}catch(_){}
        if(e.code==="permission-denied")throw err("closed","Someone has already set up this system. Sign in with the account the administrator gave you.");
        throw err(e.code,"Could not finish setup. Try again.");
      }
      return {id:uid,name,role:"Admin",slot:1,owner:true,access:ALL};
    },
    async login(name,pin){
      await noPersist;
      let cred;
      try{cred=await auth.signInWithEmailAndPassword(emailOf(name),pw(pin));}
      catch(e){
        if(net(e))throw err("network","Cannot reach the server. Check the internet connection.");
        if(e.code==="auth/too-many-requests")throw err("busy","Too many tries. Wait a few minutes and try again.");
        throw err("bad","Incorrect details. Try again.");
      }
      const d=await db.doc("workers/"+cred.user.uid).get().catch(()=>null);
      if(!d||!d.exists){await auth.signOut();throw err("removed","This account has been removed. Ask the administrator.");}
      return wfrom(d);
    },
    logout(){return auth.signOut();},
    /* re-check the signed-in worker's PIN before a destructive action */
    async verifyPin(pin){
      const u=auth.currentUser;if(!u)return false;
      try{await u.reauthenticateWithCredential(firebase.auth.EmailAuthProvider.credential(u.email,pw(pin)));return true;}
      catch(e){return false;}
    },
    /* admin adds a worker: the account is made on a second app instance so the admin stays signed in */
    async createWorker(w){
      const email=emailOf(w.name);
      const app2=firebase.apps.find(a=>a.name==="worker-create")||firebase.initializeApp(FB_CONFIG,"worker-create");
      const a2=app2.auth();await a2.setPersistence(firebase.auth.Auth.Persistence.NONE).catch(()=>{});
      let cred;
      try{cred=await a2.createUserWithEmailAndPassword(email,pw(w.pin));}
      catch(e){
        if(e.code==="auth/email-already-in-use")throw err("taken","A worker with this name already exists or was removed earlier. Use a slightly different name, for example add a middle initial.");
        if(net(e))throw err("network","Cannot reach the server. Check the internet connection.");
        throw err(e.code,"Could not create the worker. "+(e.message||""));
      }
      const uid=cred.user.uid;
      try{await a2.signOut();}catch(_){}
      try{
        await db.doc("workers/"+uid).set({name:w.name,nameLower:w.name.toLowerCase(),role:w.role,slot:w.slot,owner:false,access:w.access,created:ts()});
      }catch(e){throw err(e.code,"The account was made but could not be saved. Check your administrator access.");}
      return uid;
    },
    /* removing the worker document locks the account out of all data */
    removeWorker(uid){return db.doc("workers/"+uid).delete();},
    updateWorker(uid,patch){return db.doc("workers/"+uid).update(patch);},
    /* live list of workers (administrators only) */
    watchTeam(cb,onErr){
      return db.collection("workers").onSnapshot(s=>cb(s.docs.map(wfrom).sort((a,b)=>(a.slot||0)-(b.slot||0))),e=>{if(onErr)onErr(e);});
    },
    /* facility name/logo/receipt settings, shared by every device */
    watchFacility(cb){
      return db.doc("meta/facility").onSnapshot(s=>{if(s.exists)cb(s.data());},()=>{});
    },
    saveFacility(f){return db.doc("meta/facility").set(f);}
  };
})();
